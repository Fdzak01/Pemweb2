<x-layout>
<x-slot name="page_name">Contact</x-slot>
    <x-slot name="page_content">
        </table>
    </x-slot>
</x-layout>