<x-layout>
<x-slot name="page_name">Service</x-slot>
    <x-slot name="page_content">
    </x-slot>
</x-layout>